# ZIPP — free website preview

This folder contains a simple, phone-friendly ZIPP landing page and sample feed.

## What works
- Responsive page that opens in a modern browser
- Three sample feed screens
- Like buttons that count locally in the current page

## What is not built yet
This is a front-end preview, not a complete social network. It does not have user accounts, cloud video uploads, shared likes/comments, moderation, reporting/blocking, or a server/database.

## Open it
Open `index.html` in a browser to preview it.

## Put it online for free
You can publish this static preview with a free static-site host such as GitHub Pages or Cloudflare Pages. You will need to create an account with the hosting provider and upload the files in this folder. The host will provide a public website link. Provider setup screens and requirements can change.

Do not describe this preview as a fully working social video app until the missing backend and safety features are implemented.
